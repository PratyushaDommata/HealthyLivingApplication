package servletForms;

import javax.servlet.http.HttpServletRequest;
import domainClasses.BMI;
import domainClasses.Login;

/*Extract BMI data and validate*/
public class BMIValidationForm {
	private String height;
	private String weight;
	private BMI bmi;
	private final static String fieldCannotBeLeftEmptyMsg = "This field cannot be left empty";

	public BMIValidationForm(HttpServletRequest request) {
		bmi = extractFormData(request);
	}

	public String getHeight() {
		return height;
	}

	public String getWeight() {
		return weight;
	}

	public BMI extractFormData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		height = request.getParameter("height");
		weight = request.getParameter("weight");

		validationMsg = validationMsgForName(height);
		if (validationMsg != null) {

			request.setAttribute("errorInHeightMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(weight);
		if (validationMsg != null) {
			request.setAttribute("errorInWeightMsg", validationMsg);
			formDataValid = false;
		}
		if (!formDataValid) {
			return null;
		}
		bmi = new BMI(Double.parseDouble(height), Double.parseDouble(weight));
		return bmi;

	}

	public BMI getBmi() {
		return bmi;
	}

	private String validationMsgForName(String name) {
		if (name.length() == 0) {
			return fieldCannotBeLeftEmptyMsg;
		}
		return null;
	}

}
