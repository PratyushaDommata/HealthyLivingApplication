package servletForms;

import javax.servlet.http.HttpServletRequest;
import domainClasses.Category;
import domainClasses.Subcategory;

/*Extract Subcategory data and validate*/
public class AddSubCategoryValidationForm {
	private String subCategoryName;
	private Subcategory subCategory;
	private final static String fieldCannotBeLeftEmptyMsg = "This field cannot be left empty";

	public AddSubCategoryValidationForm(HttpServletRequest request) {
		subCategory = extractFormData(request);
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public Subcategory extractFormData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		subCategoryName = request.getParameter("subCategoryName");
		validationMsg = validationMsgForName(subCategoryName);
		if (validationMsg != null) {

			request.setAttribute("errorInSubCategoryNameMsg", validationMsg);
			formDataValid = false;
		}

		if (!formDataValid) {
			return null;
		}
		subCategory = new Subcategory(subCategoryName);
		return subCategory;

	}

	public Subcategory getSubCategory() {
		return subCategory;
	}

	private String validationMsgForName(String name) {
		if (name.length() == 0) {
			return fieldCannotBeLeftEmptyMsg;
		}
		return null;
	}

}
