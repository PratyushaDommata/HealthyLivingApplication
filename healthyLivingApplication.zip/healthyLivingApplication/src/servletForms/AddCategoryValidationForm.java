package servletForms;

import javax.servlet.http.HttpServletRequest;
import domainClasses.Category;

/*Extract Category data and validate*/
public class AddCategoryValidationForm {
	private String categoryName;
	private Category category;
	private final static String fieldCannotBeLeftEmptyMsg = "This field cannot be left empty";

	public AddCategoryValidationForm(HttpServletRequest request) {
		category = extractFormData(request);
	}

	public String getCategoryName() {
		return categoryName;
	}

	public Category extractFormData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		categoryName = request.getParameter("categoryName");
		validationMsg = validationMsgForName(categoryName);
		if (validationMsg != null) {

			request.setAttribute("errorInCategoryNameMsg", validationMsg);
			formDataValid = false;
		}

		if (!formDataValid) {
			return null;
		}
		category = new Category(categoryName);
		return category;

	}

	public Category getCategory() {
		return category;
	}

	private String validationMsgForName(String name) {
		if (name.length() == 0) {
			return fieldCannotBeLeftEmptyMsg;
		}
		return null;
	}

}
