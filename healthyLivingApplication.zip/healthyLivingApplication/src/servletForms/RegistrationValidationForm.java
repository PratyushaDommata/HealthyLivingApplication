package servletForms;

import javax.servlet.http.HttpServletRequest;
import domainClasses.Login;
import domainClasses.Registration;


/*Extract registration data and validate*/
public class RegistrationValidationForm {
	private String name;
	private String password;
	private String email;
	private String city;
	private String state;
	private String zip;
	private String phone;
	private Login login;
	private Registration registration;
	private final static String fieldCannotBeLeftEmptyMsg = "This field cannot be left empty";

	public RegistrationValidationForm(HttpServletRequest request) {
		login = extractLoginData(request);
		registration = extractRegistrationData(request);
	}

	public Login extractLoginData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		name = request.getParameter("username");
		password = request.getParameter("password");

		validationMsg = validationMsgForName(name);
		if (validationMsg != null) {

			request.setAttribute("errorInNameMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(password);
		if (validationMsg != null) {
			request.setAttribute("errorInPasswordMsg", validationMsg);
			formDataValid = false;
		}
		if (!formDataValid) {
			return null;
		}
		login = new Login(name, password);
		return login;

	}

	public Registration extractRegistrationData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		login = getLogin();
		email = request.getParameter("email");
		city = request.getParameter("city");
		state = request.getParameter("state");
		zip = request.getParameter("zip");
		phone = request.getParameter("phone");

		validationMsg = validationMsgForName(email);
		if (validationMsg != null) {

			request.setAttribute("errorInEmailMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(city);
		if (validationMsg != null) {
			request.setAttribute("errorInCityMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(state);
		if (validationMsg != null) {

			request.setAttribute("errorInStateMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(zip);
		if (validationMsg != null) {
			request.setAttribute("errorInZipMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(phone);
		if (validationMsg != null) {
			request.setAttribute("errorInPhoneMsg", validationMsg);
			formDataValid = false;
		}
		if (!formDataValid) {
			return null;
		}
		login = getLogin();
		registration = new Registration(login, email, city, state,
				Integer.parseInt(zip), Integer.parseInt(phone));
		return registration;
	}

	public Login getLogin() {
		return login;
	}

	public Registration getRegistration() {
		return registration;
	}

	public String getName() {
		return name;
	}

	public String getPassword() {
		return password;
	}

	public String getEmail() {
		return email;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getZip() {
		return zip;
	}

	public String getPhone() {
		return phone;
	}

	private String validationMsgForName(String name) {
		if (name.length() == 0) {
			return fieldCannotBeLeftEmptyMsg;
		}
		return null;
	}
}
