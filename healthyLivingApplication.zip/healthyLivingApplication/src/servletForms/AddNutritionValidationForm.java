package servletForms;

import javax.servlet.http.HttpServletRequest;
import domainClasses.Category;
import domainClasses.Subcategory;
import domainClasses.Nutrition;

/*Extract Nutrition data and validate*/
public class AddNutritionValidationForm {

	private String servingSize;
	private String fatGrams;
	private String carbsGrams;
	private String proteinGrams;
	private String calories;

	private Nutrition nutrition;

	private final static String fieldCannotBeLeftEmptyMsg = "This field cannot be left empty";

	public AddNutritionValidationForm(HttpServletRequest request) {
		nutrition = extractFormData(request);
	}

	public Nutrition extractFormData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		servingSize = request.getParameter("servingSize");
		fatGrams = request.getParameter("fatGrams");
		carbsGrams = request.getParameter("carbsGrams");
		proteinGrams = request.getParameter("proteinGrams");
		calories = request.getParameter("calories");

		validationMsg = validationMsgForName(servingSize);
		if (validationMsg != null) {

			request.setAttribute("errorInServingSizeMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(fatGrams);
		if (validationMsg != null) {

			request.setAttribute("errorInFatGramsMsg", validationMsg);
			formDataValid = false;
		}

		validationMsg = validationMsgForName(carbsGrams);
		if (validationMsg != null) {

			request.setAttribute("errorInCarbsGramsMsg", validationMsg);
			formDataValid = false;
		}

		validationMsg = validationMsgForName(proteinGrams);
		if (validationMsg != null) {

			request.setAttribute("errorInProteinGramsMsg", validationMsg);
			formDataValid = false;
		}

		validationMsg = validationMsgForName(calories);
		if (validationMsg != null) {

			request.setAttribute("errorInCaloriesMsg", validationMsg);
			formDataValid = false;
		}

		if (!formDataValid) {
			return null;
		}
		nutrition = new Nutrition(servingSize, Double.parseDouble(fatGrams),
				Double.parseDouble(carbsGrams),
				Double.parseDouble(proteinGrams), Integer.parseInt(calories));
		return nutrition;

	}

	public Nutrition getNutrition() {
		return nutrition;
	}

	public String getServingSize() {
		return servingSize;
	}

	public String getFatGrams() {
		return fatGrams;
	}

	public String getCarbsGrams() {
		return carbsGrams;
	}

	public String getProteinGrams() {
		return proteinGrams;
	}

	public String getCalories() {
		return calories;
	}

	private String validationMsgForName(String name) {
		if (name.length() == 0) {
			return fieldCannotBeLeftEmptyMsg;
		}
		return null;
	}
}
