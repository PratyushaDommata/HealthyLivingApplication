package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet to present the Home Page.
 * Note the following URL can be used to access the home page:
 * localhost:8080/healthyLivingApplication/home  (HomePageServlet presents the homepage)
 */

@WebServlet({ "/home" })
public class HomePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ServletContext context;
		RequestDispatcher dispatch;

		context = getServletContext();
		dispatch = context.getRequestDispatcher("/index.jsp");
		dispatch.forward(request, response);
	}

}
