package servlets;

import domainClasses.BMI;
import domainClasses.Category;
import domainClasses.Login;
import services.ValidateLogin;
import services.ListCategory;
import servletForms.BMIValidationForm;
import servletForms.LoginValidationForm;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet({ "/AddNutritionListCategoryServlet" })
public class AddNutritionListCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(false);
		response.setContentType("text/html");

		try {
			ArrayList<Category> catList = new ArrayList<Category>();
			catList = services.ListCategory.listCategory();
			request.setAttribute("catList", catList);
			ServletContext context = getServletContext();
			RequestDispatcher dispatch = context
					.getRequestDispatcher("/views/addNutritionListCategory.jsp");
			dispatch.forward(request, response);
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
