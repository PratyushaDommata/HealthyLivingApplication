package servlets;

import domainClasses.Login;
import services.ValidateLogin;
import servletForms.LoginValidationForm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet({ "/LoginServlet" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		response.setContentType("text/html");
		String validMsg = "Incorrect username or password";
		String un = request.getParameter("username");

		try {
			Login login;
			LoginValidationForm validation = new LoginValidationForm(request);

			login = validation.getLogin();
			if (login == null) {

				request.setAttribute("validation", validation);
				ServletContext context = getServletContext();
				RequestDispatcher dispatch = context
						.getRequestDispatcher("/views/login.jsp");
				dispatch.forward(request, response);

				return;

			}

			boolean existingLogin = services.ValidateLogin
					.ValidateUserLogin(login);
			if (existingLogin == true) {
				Login user = new Login(un);
				session.setAttribute("user", user);
				RequestDispatcher rd = getServletContext()
						.getRequestDispatcher("/views/loginConfirmation.jsp");
				rd.forward(request, response);
				return;

			} else {

				request.setAttribute("invalidCredentials", validMsg);
				ServletContext context = getServletContext();
				RequestDispatcher dispatch = context
						.getRequestDispatcher("/views/login.jsp");
				dispatch.forward(request, response);
				return;

			}

		} catch (Exception ex) {

		}

	}
}
