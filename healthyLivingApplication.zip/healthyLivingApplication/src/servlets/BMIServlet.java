package servlets;

import domainClasses.BMI;
import domainClasses.Login;
import services.ValidateLogin;
import servletForms.BMIValidationForm;
import servletForms.LoginValidationForm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet({ "/BMIServlet" })
public class BMIServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		response.setContentType("text/html");
		double results;
		double height;
		double weight;
		try {
			BMI bmi;
			BMIValidationForm validation = new BMIValidationForm(request);

			bmi = validation.getBmi();
			if (bmi == null) {

				request.setAttribute("validation", validation);
				ServletContext context = getServletContext();
				RequestDispatcher dispatch = context
						.getRequestDispatcher("/views/bmiCalculator.jsp");
				dispatch.forward(request, response);

				return;

			}

			else if (bmi != null) {
				height = Double.parseDouble(request.getParameter("height"));
				weight = Double.parseDouble(request.getParameter("weight"));
				request.setAttribute("validation", validation);
				results = (weight * 703) / (height * height);
				request.setAttribute("resultMsg", results);
				ServletContext context = getServletContext();
				RequestDispatcher dispatch = context
						.getRequestDispatcher("/views/bmiCalculator.jsp");
				dispatch.forward(request, response);
				return;

			}

		} catch (Exception ex) {

		}

	}

}
