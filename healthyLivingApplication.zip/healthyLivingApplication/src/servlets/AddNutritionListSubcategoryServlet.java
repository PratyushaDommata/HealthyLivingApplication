package servlets;

import domainClasses.BMI;
import domainClasses.Category;
import domainClasses.Login;
import domainClasses.Subcategory;
import services.ValidateLogin;
import services.ListCategory;
import servletForms.BMIValidationForm;
import servletForms.LoginValidationForm;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet({ "/AddNutritionListSubcategoryServlet" })
public class AddNutritionListSubcategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(false);
		response.setContentType("text/html");

		try {
			String cat = request.getParameter("CategoryName");
			Category category = new Category(cat);
			ArrayList<Subcategory> subcatList = new ArrayList<Subcategory>();
			subcatList = services.ListSubCategory.listSubCategory(category);

			request.setAttribute("subcatList", subcatList);
			ServletContext context = getServletContext();
			RequestDispatcher dispatch = context
					.getRequestDispatcher("/views/addNutritionListSubcategory.jsp");
			dispatch.forward(request, response);
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
