package servlets;

import domainClasses.BMI;
import domainClasses.Category;
import domainClasses.Registration;
import domainClasses.Subcategory;
import domainClasses.Nutrition;
import domainClasses.Login;
import services.ValidateLogin;
import services.ListCategory;
import services.ListSubCategory;
import services.AddNewCategory;
import servletForms.BMIValidationForm;
import servletForms.LoginValidationForm;
import servletForms.RegistrationValidationForm;
import servletForms.AddCategoryValidationForm;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet({ "/AddCategoryServlet" })
public class AddCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		try {
			AddCategoryValidationForm validation = new AddCategoryValidationForm(
					request);

			Category category = validation.getCategory();

			if (category == null) {
				request.setAttribute("validation", validation);
				ServletContext context = getServletContext();
				RequestDispatcher dispatch = context
						.getRequestDispatcher("/views/addCategory.jsp");
				dispatch.forward(request, response);

				return;

			}
			String categoryName = category.getCategoryName();
			services.AddNewCategory.insertCategory(categoryName);

			ServletContext context = getServletContext();
			RequestDispatcher dispatch = context
					.getRequestDispatcher("/views/insertSuccess.jsp");
			dispatch.forward(request, response);

		} catch (SQLException e) {

			e.printStackTrace();
		} catch (NamingException e) {

			e.printStackTrace();
		}
		out.println("</body></html>");

	}

}
