package servlets;

import domainClasses.BMI;
import domainClasses.Category;
import domainClasses.Subcategory;
import domainClasses.Nutrition;
import domainClasses.Login;
import services.ValidateLogin;
import services.ListCategory;
import services.ListSubCategory;
import servletForms.BMIValidationForm;
import servletForms.LoginValidationForm;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet({ "/ListNutritionInfoServlet" })
public class ListNutritionInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(true);
		response.setContentType("text/html");

		try {

			String subcat = request.getParameter("Subcategory");
			Subcategory subcategory = new Subcategory(subcat);
			ArrayList<Nutrition> nutritionList = new ArrayList<Nutrition>();
			nutritionList = services.ListNutritionInfo
					.listNutrition(subcategory);
			request.setAttribute("nutritionList", nutritionList);
			request.setAttribute("subcat", subcat);
			ServletContext context = getServletContext();
			RequestDispatcher dispatch = context
					.getRequestDispatcher("/views/listNutritionInfo.jsp");
			dispatch.forward(request, response);
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
