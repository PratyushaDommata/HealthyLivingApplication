package domainClasses;

public class Nutrition {
	int nutritionId;
	String servingSize;
	double fatGrams;
	double carbsGrams;
	double proteinGrams;
	int calories;
	int subcategoryId;

	public Nutrition(int nutritionId, String servingSize, double fatGrams,
			double carbsGrams, double proteinGrams, int calories,
			int subcategoryId) {
		this.nutritionId = nutritionId;
		this.servingSize = servingSize;
		this.fatGrams = fatGrams;
		this.carbsGrams = carbsGrams;
		this.proteinGrams = proteinGrams;
		this.calories = calories;
		this.subcategoryId = subcategoryId;
	}

	public Nutrition(String servingSize, double fatGrams, double carbsGrams,
			double proteinGrams, int calories) {
		this.servingSize = servingSize;
		this.fatGrams = fatGrams;
		this.carbsGrams = carbsGrams;
		this.proteinGrams = proteinGrams;
		this.calories = calories;

	}

	public int getNutritionId() {
		return nutritionId;
	}

	public String getServingSize() {
		return servingSize;
	}

	public double getFatGrams() {
		return fatGrams;
	}

	public double getCarbsGrams() {
		return carbsGrams;
	}

	public double getProteinGrams() {
		return proteinGrams;
	}

	public int getCalories() {
		return calories;
	}

	public int getSubcategoryId() {
		return subcategoryId;
	}

	public void setNutritionId(int newNutritionId) {
		nutritionId = newNutritionId;
	}

	public void setServingSize(String newServingSize) {
		servingSize = newServingSize;
	}

	public void setFatGrams(double newFatGrams) {
		fatGrams = newFatGrams;
	}

	public void setCarbsGrams(double newCarbsGrams) {
		carbsGrams = newCarbsGrams;
	}

	public void setProteinGrams(double newProteinGrams) {
		proteinGrams = newProteinGrams;
	}

	public void setCalories(int newCalories) {
		calories = newCalories;
	}

	public void setSubcategoryId(int newSubcategoryId) {
		subcategoryId = newSubcategoryId;
	}

}
