package domainClasses;

public class Category {
	int categoryId;
	String categoryName;

	public Category() {

	}

	public Category(String categoryName) {
		this.categoryName = categoryName;
	}

	public Category(int categoryId, String categoryName) {
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void seCategory_id(int newcategoryId) {
		categoryId = newcategoryId;
	}

	public void setCategory_name(String newcategoryName) {
		categoryName = newcategoryName;
	}

	public String toString() {
		return categoryId + " " + categoryName;
	}

}
