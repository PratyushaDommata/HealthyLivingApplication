package domainClasses;

public class Subcategory {
	int subCategoryId;
	String subCategoryName;
	int categoryId;

	public Subcategory(int subcategoryId, String subcategoryName, int categoryId) {
		this.subCategoryId = subcategoryId;
		this.subCategoryName = subcategoryName;
		this.categoryId = categoryId;
	}

	public Subcategory(String subcategoryName) {

		this.subCategoryName = subcategoryName;
	}

	public Subcategory(String subcategoryName, int categoryId) {
		this.subCategoryName = subcategoryName;
		this.categoryId = categoryId;
	}

	public int getSubCategoryId() {
		return subCategoryId;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setSubcategoryId(int newSubCategoryId) {
		subCategoryId = newSubCategoryId;
	}

	public void setSubcategoryName(String newSubCategoryName) {
		subCategoryName = newSubCategoryName;
	}

	public void setCategoryId(int newCategory_id) {
		categoryId = newCategory_id;
	}
}
