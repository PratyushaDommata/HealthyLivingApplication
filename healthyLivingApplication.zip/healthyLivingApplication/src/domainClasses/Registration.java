package domainClasses;

public class Registration {

	private Login login;
	private String email;
	private String city;
	private String state;
	private int zip;
	private int phone;

	public Registration() {
	}

	public Registration(Login login, String email, String city, String state,
			int zip, int phone) {
		this.login = login;
		this.email = email;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.phone = phone;

	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String toString() {
		return "User[username:" + login.username + "," + " password: "
				+ login.password + ", email: " + email + ", " + "city: " + city
				+ ", state: " + state + ", zip: " + zip + ", phone: " + phone
				+ "]";
	}

}
