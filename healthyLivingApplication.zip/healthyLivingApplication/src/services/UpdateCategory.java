package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.NutritionDb;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;

public class UpdateCategory {
	/* This method is used to update a category */
	public static void updateCategory(String categoryName, int categoryId)
			throws SQLException, NamingException {
		Connection dbConn;
		Statement queryStmt = null;

		String queryStr = "UPDATE Nutritiondb.category set category_name = '"
				+ categoryName + "'  " + "WHERE category_id=" + categoryId
				+ ";";
		dbConn = NutritionDb.getConnection();
		dbConn.setAutoCommit(false);
		try {
			dbConn = NutritionDb.getConnection();
			queryStmt = dbConn.createStatement();

			int result = queryStmt.executeUpdate(queryStr);

			if (result != 1) {
				dbConn.rollback();
			}
			// Free resources
			else
				dbConn.commit();

			queryStmt.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
}
