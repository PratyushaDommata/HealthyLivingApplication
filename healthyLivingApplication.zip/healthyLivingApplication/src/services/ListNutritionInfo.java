package services;

import domainClasses.Login;
import domainClasses.Nutrition;
import domainClasses.Registration;
import database.NutritionDb;
import domainClasses.Category;
import domainClasses.Subcategory;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class ListNutritionInfo {
	/*This method is used to list nutrition details*/
	public static ArrayList<Nutrition> listNutrition(Subcategory subcategory)
			throws SQLException, NamingException {

		Connection dbConn = null;
		Statement queryStmt = null;
		ResultSet results = null;
		String subcategoryName = subcategory.getSubCategoryName();

		String queryStr = "select n.* from Nutritiondb.nutrition n join Nutritiondb.subcategory s "
				+ "on n.subcategory_id=s.subcategory_id where "
				+ "s.subcategory_name = '" + subcategoryName + "';";
		Nutrition nutrition = null;

		ArrayList<Nutrition> nutritionList = new ArrayList<Nutrition>();

		String servingSize;
		int nutritionId, subcategoryId, calories;
		double fatGrams, carbsGrams, proteinGrams;

		try {

			dbConn = NutritionDb.getConnection();
			queryStmt = dbConn.createStatement();
			results = queryStmt.executeQuery(queryStr);
			while (results.next()) { // process results
				nutritionId = results.getInt("nutrition_id");
				servingSize = results.getString("serving_size");
				fatGrams = results.getDouble("fat_grams");
				carbsGrams = results.getDouble("carbs_grams");
				proteinGrams = results.getDouble("protein_grams");
				calories = results.getInt("calories");
				subcategoryId = results.getInt("subcategory_id");

				nutrition = new Nutrition(nutritionId, servingSize, fatGrams,
						carbsGrams, proteinGrams, calories, subcategoryId);
				nutritionList.add(nutrition);

			}
		} catch (SQLException ex) {

		} finally {
			try {

				if (results != null && !results.isClosed())
					results.close();
				if (queryStmt != null && !queryStmt.isClosed())
					queryStmt.close();

			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}

		// Free resources
		return nutritionList;

	}
}