package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.NutritionDb;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;

public class AddNewSubCategory {
	/* This method is used to insert a new subcategory */
	public static void insertSubCategory(String subCategoryName, int categoryId)
			throws SQLException, NamingException {
		Connection dbConn;

		String queryStr = "INSERT INTO Nutritiondb.subcategory(subcategory_name,category_id) VALUES (?,?);";
		dbConn = NutritionDb.getConnection();
		dbConn.setAutoCommit(false);
		try (PreparedStatement queryStmt = dbConn.prepareStatement(queryStr)) {

			queryStmt.setString(1, subCategoryName);
			queryStmt.setInt(2, categoryId);

			int result = queryStmt.executeUpdate();

			if (result != 1) {
				dbConn.rollback();
			}
			// Free resources
			else
				dbConn.commit();

			queryStmt.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

}
