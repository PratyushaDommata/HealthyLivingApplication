package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.NutritionDb;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;

public class AddNutrition {
	/* This method is used to insert a nutrition info */
	public static void insertNutrition(String servingSize, double fatGrams,
			double carbsGrams, double proteinGrams, int calories,
			int subcategoryId) throws SQLException, NamingException {
		Connection dbConn;

		String queryStr = "INSERT INTO Nutritiondb.nutrition(serving_size,fat_grams,carbs_grams,protein_grams,calories,subcategory_id)"
				+ " VALUES (?,?,?,?,?,?);";
		dbConn = NutritionDb.getConnection();
		dbConn.setAutoCommit(false);
		try (PreparedStatement queryStmt = dbConn.prepareStatement(queryStr)) {

			queryStmt.setString(1, servingSize);
			queryStmt.setDouble(2, fatGrams);
			queryStmt.setDouble(3, carbsGrams);
			queryStmt.setDouble(4, proteinGrams);
			queryStmt.setInt(5, calories);
			queryStmt.setInt(6, subcategoryId);
			int result = queryStmt.executeUpdate();

			if (result != 1) {
				dbConn.rollback();
			}
			// Free resources
			else
				dbConn.commit();

			queryStmt.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

}
