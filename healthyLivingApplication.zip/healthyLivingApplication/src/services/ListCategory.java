package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.NutritionDb;
import domainClasses.Category;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class ListCategory {
	/* This method is used to list category */
	public static ArrayList<Category> listCategory() throws SQLException,
			NamingException {

		Connection dbConn = null;
		Statement queryStmt = null;
		ResultSet results = null;

		String queryStr = "Select category_id,category_name from Nutritiondb.category;";
		Category category = null;

		ArrayList<Category> catList = new ArrayList<Category>();

		String categoryName;
		int categoryId;

		try {

			dbConn = NutritionDb.getConnection();
			queryStmt = dbConn.createStatement();
			results = queryStmt.executeQuery(queryStr);
			while (results.next()) { // process results
				categoryId = results.getInt("category_id");
				categoryName = results.getString("category_name");

				category = new Category(categoryId, categoryName);
				catList.add(category);

			}
		} catch (SQLException ex) {

		} finally {
			try {

				if (results != null && !results.isClosed())
					results.close();
				if (queryStmt != null && !queryStmt.isClosed())
					queryStmt.close();

			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}

		// Free resources
		return catList;

	}
}
