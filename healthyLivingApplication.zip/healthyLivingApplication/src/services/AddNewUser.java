package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.NutritionDb;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;

public class AddNewUser {
	/* This method is used to insert a new user */
	public static void insertUser(Registration registration)
			throws SQLException, NamingException {
		Connection dbConn;
		Login newLogin;

		String queryStr = "INSERT INTO Nutritiondb.registration(user_name,enter_password,email_address,city,state,zip,phone)"
				+ "VALUES(?,?,?,?,?,?,?);";
		dbConn = NutritionDb.getConnection();
		dbConn.setAutoCommit(false);
		try (PreparedStatement queryStmt = dbConn.prepareStatement(queryStr)) {
			newLogin = registration.getLogin();
			queryStmt.setString(1, newLogin.getUsername());
			queryStmt.setString(2, newLogin.getPassword());
			queryStmt.setString(3, registration.getEmail());
			queryStmt.setString(4, registration.getCity());
			queryStmt.setString(5, registration.getState());
			queryStmt.setInt(6, registration.getZip());
			queryStmt.setInt(7, registration.getPhone());

			int result = queryStmt.executeUpdate();

			if (result != 1) {
				dbConn.rollback();
			}
			// Free resources
			else
				dbConn.commit();

			queryStmt.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

}
