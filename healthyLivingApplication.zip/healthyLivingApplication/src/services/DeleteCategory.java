package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.NutritionDb;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;

public class DeleteCategory {
	/* This method is used to delete a category */
	public static void deleteCategory(int categoryId) throws SQLException,
			NamingException {
		Connection dbConn;
		Statement queryStmt = null;

		String queryStr = "DELETE FROM Nutritiondb.category WHERE category_id="
				+ categoryId + ";";
		dbConn = NutritionDb.getConnection();
		dbConn.setAutoCommit(false);
		try {
			dbConn = NutritionDb.getConnection();
			queryStmt = dbConn.createStatement();

			int result = queryStmt.executeUpdate(queryStr);

			if (result != 1) {
				dbConn.rollback();
			}
			// Free resources
			else
				dbConn.commit();

			queryStmt.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}
}
