package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.NutritionDb;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;

public class AddNewCategory {
	/* This method is used to insert a new category */
	public static void insertCategory(String categoryName) throws SQLException,
			NamingException {
		Connection dbConn;

		String queryStr = "INSERT INTO Nutritiondb.category(category_name) VALUES (?);";
		dbConn = NutritionDb.getConnection();
		dbConn.setAutoCommit(false);
		try (PreparedStatement queryStmt = dbConn.prepareStatement(queryStr)) {

			queryStmt.setString(1, categoryName);

			int result = queryStmt.executeUpdate();

			if (result != 1) {
				dbConn.rollback();
			}
			// Free resources
			else
				dbConn.commit();

			queryStmt.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

}