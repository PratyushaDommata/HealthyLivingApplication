package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.NutritionDb;
import domainClasses.Category;
import domainClasses.Subcategory;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class ListSubCategory {
	/* This method is used to list subcategory */
	public static ArrayList<Subcategory> listSubCategory(Category category)
			throws SQLException, NamingException {

		Connection dbConn = null;
		Statement queryStmt = null;
		ResultSet results = null;
		String categoryName = category.getCategoryName();

		String queryStr = "select s.* from Nutritiondb.subcategory s join Nutritiondb.category c on s.category_id = c.category_id where"
				+ " c.category_name= '" + categoryName + "';";
		Subcategory subCategory = null;

		ArrayList<Subcategory> subcatList = new ArrayList<Subcategory>();

		String subCategoryName;
		int subCategoryId, categoryId;

		try {

			dbConn = NutritionDb.getConnection();
			queryStmt = dbConn.createStatement();
			results = queryStmt.executeQuery(queryStr);
			while (results.next()) { // process results
				categoryId = results.getInt("category_id");
				subCategoryName = results.getString("subcategory_name");
				subCategoryId = results.getInt("subcategory_id");

				subCategory = new Subcategory(subCategoryId, subCategoryName,
						categoryId);
				subcatList.add(subCategory);

			}
		} catch (SQLException ex) {

		} finally {
			try {

				if (results != null && !results.isClosed())
					results.close();
				if (queryStmt != null && !queryStmt.isClosed())
					queryStmt.close();

			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}

		// Free resources
		return subcatList;

	}
}