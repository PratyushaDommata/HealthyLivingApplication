CREATE SCHEMA `Nutritiondb` ;

CREATE TABLE `Nutritiondb`.`category` 
  (
  `category_id` INT NOT NULL AUTO_INCREMENT,
  `category_name` VARCHAR(20) NOT NULL,
   PRIMARY KEY (`category_id`)
  );
  
INSERT INTO `Nutritiondb`.`category`(`category_name`) VALUES ('Fruits');
INSERT INTO `Nutritiondb`.`category` (`category_name`) VALUES ('Vegetables');
INSERT INTO `Nutritiondb`.`category` (`category_name`) VALUES ('Seafood');




  CREATE TABLE `Nutritiondb`.`subcategory` 
  (
  `subcategory_id` INT NOT NULL AUTO_INCREMENT,
  `subcategory_name` VARCHAR(30) NOT NULL,
  `category_id` INT NOT NULL, 
  PRIMARY KEY (`subcategory_id`),
  FOREIGN KEY(`category_id`) REFERENCES `Nutritiondb`.`category`(`category_id`) 
  ON DELETE CASCADE
  ON UPDATE CASCADE
  );

INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Apple', 1);
INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Cherries', 1);
INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Oranges', 1);

INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Broccoli', 2);
INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Cabbage', 2);
INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Eggplant', 2);

INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Atlantic Salmon', 3);
INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Crab', 3);
INSERT INTO `Nutritiondb`.`subcategory` (`subcategory_name`, `category_id`) VALUES ('Lobster', 3);

  

  CREATE TABLE `Nutritiondb`.`nutrition`
  (
  `nutrition_id` INT NOT NULL AUTO_INCREMENT,
  `serving_size` VARCHAR(20) NOT NULL,
  `fat_grams` DECIMAL(5,2) NOT NULL,
  `carbs_grams` DECIMAL(5,2) NOT NULL,
  `protein_grams` DECIMAL(5,2) NOT NULL,
  `calories` INT NOT NULL,
  `subcategory_id` INT NOT NULL, 
  PRIMARY KEY (`nutrition_id`),
  FOREIGN KEY(`subcategory_id`) REFERENCES `Nutritiondb`.`subcategory`(`subcategory_id`)
  ON DELETE CASCADE
  ON UPDATE CASCADE
  );
  
INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('1 medium', '0.23','19.06','0.36',72,1);

INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('1 cup', '0.23','18.73','1.24',74,2);

INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('1 medium', '0.16','15.39','1.23',62,3);

INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('1 oz', '0.10','1.88','0.80',10,4);

INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('1 oz', '0.03','1.58','0.41',7,5);

INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('1 oz', '0.05','1.62','0.29',7,6);

INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('i/2 fillet', '21.48','0','39.4',362,7);

INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('1 medium', '3.00','0.05','9.08',65,8);

INSERT INTO `Nutritiondb`.`nutrition`(`serving_size`,`fat_grams`,`carbs_grams`,`protein_grams`,`calories`,`subcategory_id`) 
VALUES ('1 medium', '1.71','3.75','59.97',286,9);


  CREATE TABLE `Nutritiondb`.`registration` 
  (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `user_name` VARCHAR(20) NOT NULL,
  `enter_password` VARCHAR(20) NOT NULL,
  `email_address` VARCHAR(40) NOT NULL,
  `city` VARCHAR(20) NOT NULL,
  `state` VARCHAR(20) NOT NULL,
  `zip` int NOT NULL,
  `phone` bigint NOT NULL,
   PRIMARY KEY (`user_id`)
  );

INSERT INTO `Nutritiondb`.`registration`(`user_name`,`enter_password`,`email_address`,`city`,`state`,`zip`,`phone`) 
VALUES ('pratyusha', 'pra@12','pra@yahoo.com','Fremont','CA',94539,123456789);

INSERT INTO `Nutritiondb`.`registration`(`user_name`,`enter_password`,`email_address`,`city`,`state`,`zip`,`phone`) 
VALUES ('srikanth', 'sri@12','sri@yahoo.com','Albany','NY',12201,234234234);

INSERT INTO `Nutritiondb`.`registration`(`user_name`,`enter_password`,`email_address`,`city`,`state`,`zip`,`phone`) 
VALUES ('pranav', 'panni@12','panni@yahoo.com','Avalon','NJ',08202,123434561);


  