CREATE USER 'nutrition_user'@'localhost' IDENTIFIED BY 'pswdForNutritiondb';

GRANT ALL PRIVILEGES ON Nutritiondb.* TO 'nutrition_user'@'localhost' WITH GRANT OPTION;

SHOW GRANTS FOR 'nutrition_user'@'localhost';
